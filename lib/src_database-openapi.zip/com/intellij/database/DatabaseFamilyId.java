/*
 * Copyright 2000-2014 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.database;

import com.intellij.database.model.DasDataSource;
import com.intellij.database.model.NameVersion;
import com.intellij.database.model.RawConnectionConfig;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Version;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.ConcurrencyUtil;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.TestOnly;

import java.util.Collection;
import java.util.concurrent.ConcurrentMap;

/**
 * @author gregsh
 */
public final class DatabaseFamilyId implements Comparable<DatabaseFamilyId> {

  private final static ConcurrentMap<String, DatabaseFamilyId> ourFamilies = ContainerUtil.newConcurrentMap();

  @NotNull
  public static DatabaseFamilyId create(@NotNull String displayName) {
    return create(displayName, displayName);
  }

  @NotNull
  public static DatabaseFamilyId create(@NotNull String name, @NotNull String displayName) {
    name = StringUtil.toUpperCase(name); // force uppercase
    DatabaseFamilyId existing = ourFamilies.get(name);
    if (existing != null) return existing;
    return ConcurrencyUtil.cacheOrGet(ourFamilies, name, new DatabaseFamilyId(name, displayName));
  }


  // supported dialects
  public static final DatabaseFamilyId UNKNOWN = create("UNKNOWN");
  public static final DatabaseFamilyId ORACLE = create("Oracle");
  public static final DatabaseFamilyId MEMSQL = create("MemSQL");
  public static final DatabaseFamilyId MARIADB = create("MariaDB"); //should be before MYSQL for correct detection
  public static final DatabaseFamilyId MYSQL = create("MySQL");
  public static final DatabaseFamilyId POSTGRES = create("Postgres");
  public static final DatabaseFamilyId REDSHIFT = create("RedShift");
  public static final DatabaseFamilyId MSSQL = create("MSSQL", "SQLServer");
  public static final DatabaseFamilyId SYBASE = create("Sybase");
  public static final DatabaseFamilyId DB2 = create("DB2");
  public static final DatabaseFamilyId SQLITE = create("SQLite");
  public static final DatabaseFamilyId HSQLDB = create("HSQLDB");
  public static final DatabaseFamilyId H2 = create("H2");
  public static final DatabaseFamilyId DERBY = create("Derby");
  public static final DatabaseFamilyId EXASOL = create("Exasol");
  public static final DatabaseFamilyId CLICKHOUSE = create("ClickHouse");

  // unsupported dialects
  public static final DatabaseFamilyId VERTICA = create("Vertica");
  public static final DatabaseFamilyId PRESTO = create("Presto");
  public static final DatabaseFamilyId INFORMIX = create("Informix");
  public static final DatabaseFamilyId IMPALA = create("Impala");
  public static final DatabaseFamilyId NETEZZA = create("Netezza");
  public static final DatabaseFamilyId PHOENIX = create("Phoenix");
  public static final DatabaseFamilyId HIVE = create("Hive");
  public static final DatabaseFamilyId SNOWFLAKE = create("Snowflake");
  public static final DatabaseFamilyId INGRES = create("Ingres");
  public static final DatabaseFamilyId TERADATA = create("Teradata");
  public static final DatabaseFamilyId OPENEDGE = create("OpenEdge");
  public static final DatabaseFamilyId TIBERO = create("Tibero");
  public static final DatabaseFamilyId FILEMAKER = create("FileMaker");
  public static final DatabaseFamilyId FRONTBASE = create("FrontBase");

  private final String myName;
  private final String myDisplayName;

  private DatabaseFamilyId(@NotNull String name, @NotNull String displayName) {
    myName = name;
    myDisplayName = displayName;
  }

  @NotNull
  public String getName() {
    return myName;
  }

  @NotNull
  public String getDisplayName() {
    return myDisplayName;
  }

  @Override
  public String toString() {
    return getName();
  }

  public boolean isOracle() { return this == ORACLE; }
  public boolean isMysql() { return this == MYSQL || this == MARIADB || this == MEMSQL; }
  public boolean isPostgres() { return this == POSTGRES || this == REDSHIFT; }
  public boolean isRedshift() { return this == REDSHIFT; }
  public boolean isVertica() {return this == VERTICA; }
  public boolean isMicrosoft() { return this == MSSQL; }
  public boolean isSybase() { return this == SYBASE; }
  public boolean isDb2() { return this == DB2; }
  public boolean isHsqldb() { return this == HSQLDB; }
  public boolean isH2() { return this == H2; }
  public boolean isDerby() { return this == DERBY; }
  public boolean isSqlite() { return this == SQLITE; }
  public boolean isTransactSql() { return isMicrosoft() || isSybase(); }
  public boolean isExasol() { return this == EXASOL; }

  @NotNull
  public static DatabaseFamilyId forDataSource(@NotNull DasDataSource o) {
    NameVersion p = o.getDatabaseVersion();
    DatabaseFamilyId result = fromString(p.version);
    if (result == UNKNOWN) {
      result = fromString(p.name);
    }
    if (result == UNKNOWN && o instanceof RawConnectionConfig) {
      result = forConnection((RawConnectionConfig)o);
    }
    if (result == POSTGRES) {
      Version version = p.version != null && p.version.contains("8") ? Version.parseVersion(p.version) : null;
      if (version != null && version.major == 8 && version.bugfix == 2) {
        result = REDSHIFT;
      }
    }
    return result;
  }

  @NotNull
  public static DatabaseFamilyId forConnection(@Nullable RawConnectionConfig o) {
    if (o == null) return UNKNOWN;
    DatabaseFamilyId result = fromString(o.getUrl());
    if (result != UNKNOWN) return result;
    return fromString(o.getDriverClass());
  }

  @NotNull
  public static DatabaseFamilyId fromString(@Nullable String text) {
    if (text == null) return UNKNOWN;
    String pattern = "(?i).*(?:%s).*";
    for (DatabaseFamilyId family : ourFamilies.values()) {
      if (text.matches(String.format(pattern, family.getName()))) return family;
    }
    if (text.matches(String.format(pattern, "hsql"))) return HSQLDB;
    if (text.matches(String.format(pattern, "microsoft|sqlserver"))) return MSSQL;
    if (text.matches(String.format(pattern, "adaptive server")) || text.startsWith("ase")) return SYBASE;
    if (text.startsWith("ids")) return INFORMIX;
    if (text.matches(String.format(pattern, "exa"))) return EXASOL;
    return UNKNOWN;
  }

  @Nullable
  public static DatabaseFamilyId byName(@NotNull String name) {
    return ourFamilies.get(name);
  }

  @TestOnly
  public static Collection<DatabaseFamilyId> allFamilyIds() {
    return ourFamilies.values();
  }

  @Override
  public int compareTo(@NotNull DatabaseFamilyId o) {
    return Comparing.compare(getName(), o.getName());
  }
}
