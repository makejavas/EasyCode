/*
 * Copyright 2000-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.database.model;

import com.intellij.util.containers.hash.LinkedHashMap;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static java.lang.String.format;

/**
 * Kind o database object.
 * @author Leonid Bushuev from JetBrains
 */
public class ObjectKind implements Comparable<ObjectKind> {

  public static final ObjectKind NONE                 = new ObjectKind("NONE"                , 0);
  public static final ObjectKind ROOT                 = new ObjectKind("ROOT"                , 1);
  public static final ObjectKind DATABASE             = new ObjectKind("DATABASE"            , 2);
  public static final ObjectKind SCHEMA               = new ObjectKind("SCHEMA"              , 3);
  public static final ObjectKind SEQUENCE             = new ObjectKind("SEQUENCE"            , 4);
  public static final ObjectKind CLUSTER              = new ObjectKind("CLUSTER"             , 5);
  public static final ObjectKind OBJECT_TYPE          = new ObjectKind("OBJECT TYPE"         , 6);
  public static final ObjectKind COLLECTION_TYPE      = new ObjectKind("COLLECTION TYPE"     , 7);
  public static final ObjectKind TABLE_TYPE           = new ObjectKind("TABLE TYPE"          , 8);
  public static final ObjectKind ALIAS_TYPE           = new ObjectKind("ALIAS TYPE"          , 9);
  public static final ObjectKind TABLE                = new ObjectKind("TABLE"               , 10);
  public static final ObjectKind MAT_LOG              = new ObjectKind("MATERIALIZED LOG"    , 11);
  public static final ObjectKind MAT_VIEW             = new ObjectKind("MATERIALIZED VIEW"   , 12);
  public static final ObjectKind VIEW                 = new ObjectKind("VIEW"                , 13);
  public static final ObjectKind PACKAGE              = new ObjectKind("PACKAGE"             , 14);
  public static final ObjectKind BODY                 = new ObjectKind("BODY"                , 15);
  public static final ObjectKind ROUTINE              = new ObjectKind("ROUTINE"             , 16);
  public static final ObjectKind OPERATOR             = new ObjectKind("OPERATOR"            , 17);
  public static final ObjectKind OBJECT_ATTRIBUTE     = new ObjectKind("OBJECT ATTRIBUTE"    , 18);
  public static final ObjectKind COLUMN               = new ObjectKind("COLUMN"              , 19);
  public static final ObjectKind INDEX                = new ObjectKind("INDEX"               , 20);
  public static final ObjectKind KEY                  = new ObjectKind("KEY"                 , 21);
  public static final ObjectKind FOREIGN_KEY          = new ObjectKind("FOREIGN KEY"         , 22);
  public static final ObjectKind CHECK                = new ObjectKind("CHECK"               , 23);
  public static final ObjectKind DEFAULT              = new ObjectKind("DEFAULT"             , 24);
  public static final ObjectKind RULE                 = new ObjectKind("RULE"                , 25);
  public static final ObjectKind TRIGGER              = new ObjectKind("TRIGGER"             , 26);
  public static final ObjectKind ARGUMENT             = new ObjectKind("ARGUMENT"            , 27);
  public static final ObjectKind VARIABLE             = new ObjectKind("VARIABLE"            , 28);
  public static final ObjectKind COMMENT              = new ObjectKind("COMMENT"             , 29);
  public static final ObjectKind SYNONYM              = new ObjectKind("SYNONYM"             , 30);
  public static final ObjectKind DB_LINK              = new ObjectKind("DBLINK"              , 31);
  public static final ObjectKind VIRTUAL_TABLE        = new ObjectKind("VIRTUAL TABLE"       , 32);
  public static final ObjectKind COLLATION            = new ObjectKind("COLLATION"           , 33);
  public static final ObjectKind SCRIPT               = new ObjectKind("SCRIPT"              , 34);
  public static final ObjectKind TABLESPACE           = new ObjectKind("TABLESPACE"          , 35);
  public static final ObjectKind DATA_FILE            = new ObjectKind("DATA FILE"           , 36);
  public static final ObjectKind ROLE                 = new ObjectKind("ROLE"                , 37);
  public static final ObjectKind USER                 = new ObjectKind("USER"                , 38);
  public static final ObjectKind CONNECTION           = new ObjectKind("CONNECTION"          , 39);
  public static final ObjectKind FOREIGN_DATA_WRAPPER = new ObjectKind("FOREIGN DATA WRAPPER", 40);
  public static final ObjectKind SERVER               = new ObjectKind("SERVER"              , 41);
  public static final ObjectKind USER_MAPPING         = new ObjectKind("USER MAPPING"        , 42);
  public static final ObjectKind FOREIGN_TABLE        = new ObjectKind("FOREIGN TABLE"       , 43);
  public static final ObjectKind EXTERNAL_SCHEMA      = new ObjectKind("EXTERNAL SCHEMA"     , 44);
  public static final ObjectKind SCHEDULED_EVENT      = new ObjectKind("SCHEDULED EVENT"     , 45);
  public static final ObjectKind ACCESS_METHOD        = new ObjectKind("ACCESS METHOD"       , 46);
  public static final ObjectKind AGGREGATE            = new ObjectKind("AGGREGATE"           , 47);
  public static final ObjectKind EXCEPTION            = new ObjectKind("EXCEPTION"           , 48);

  public static final ObjectKind UNKNOWN_OBJECT       = new ObjectKind("UNKNOWN OBJECT"      , Integer.MAX_VALUE);

  private final String myName;
  private final int myOrderNum;

  private static final AtomicInteger ourOrderNumCounter = new AtomicInteger(100);
  private final String myCode;

  public ObjectKind(@NotNull String name) {
    this(name, ourOrderNumCounter.incrementAndGet());
  }

  private ObjectKind(@NotNull String name, int orderNum) {
    assert name.length() > 0;
    assert orderNum >= 0;
    myName = name;
    myCode = myName.toLowerCase(Locale.ENGLISH).replace(' ', '-');
    myOrderNum = orderNum;
  }

  public String name() {
    return myName;
  }

  /**
   * Returns the formal code, that can be used to write it into a file.
   * This code also XML-friendly, starts with a letter and can contain
   * letters, digits and dashes.
   * @return the formal code.
   */
  public String code() {
    return myCode;
  }

  /**
   * Returns the order number influences on order of this kind of elements in the script.
   * @return non-negative integer order number.
   */
  public int getOrder() {
    return myOrderNum;
  }

  @Override
  public String toString() {
    return code();
  }

  @Override
  public int compareTo(@NotNull ObjectKind that) {
    if (this == that) return 0;
    if (this.myOrderNum < that.myOrderNum) return -1;
    if (this.myOrderNum > that.myOrderNum) return +1;
    throw new IllegalStateException(format("Uncomparable object kinds: %s and %s", this.code(), that.code()));
  }

  public static final Map<String,ObjectKind> ourKinds;

  static {
    ObjectKind[] theKinds = {
      NONE,
      ROOT,
      DATABASE,
      SCHEMA,
      SEQUENCE,
      CLUSTER,
      TABLE,
      MAT_LOG,
      MAT_VIEW,
      VIEW,
      OBJECT_TYPE,
      COLLECTION_TYPE,
      PACKAGE,
      BODY,
      TABLE_TYPE,
      ALIAS_TYPE,
      ROUTINE,
      OPERATOR,
      OBJECT_ATTRIBUTE,
      COLUMN,
      INDEX,
      KEY,
      FOREIGN_KEY,
      CHECK,
      DEFAULT,
      RULE,
      TRIGGER,
      ARGUMENT,
      VARIABLE,
      COMMENT,
      SYNONYM,
      DB_LINK,
      VIRTUAL_TABLE,
      COLLATION,
      SCRIPT,
      USER,
      ROLE,
      CONNECTION,
      FOREIGN_DATA_WRAPPER,
      SERVER,
      USER_MAPPING,
      FOREIGN_TABLE,
      EXTERNAL_SCHEMA,
      SCHEDULED_EVENT,
      ACCESS_METHOD,
      AGGREGATE,
      EXCEPTION,
      UNKNOWN_OBJECT,
    };
    LinkedHashMap<String, ObjectKind> m = new LinkedHashMap<>(60);
    for (ObjectKind kind : theKinds) m.put(kind.code(), kind);
    ourKinds = Collections.unmodifiableMap(m);
  }

}
