/*
 * Copyright 2000-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.sql.formatter.settings;

import com.intellij.database.util.Case;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import com.intellij.psi.codeStyle.CommonCodeStyleSettings;
import com.intellij.psi.codeStyle.CustomCodeStyleSettings;
import com.intellij.sql.psi.SqlLanguage;
import org.intellij.lang.annotations.MagicConstant;
import org.jdom.Element;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static com.intellij.psi.codeStyle.CommonCodeStyleSettings.*;
import static com.intellij.sql.formatter.settings.SqlCodeStyleSettingsDefault.LEGACY;
import static com.intellij.sql.formatter.settings.SqlCodeStyleSettingsDefault.MODERN;
import static java.lang.String.format;


/**
 * @author Gregory.Shrago, ignatov
 */
@SuppressWarnings({"DeprecatedIsStillUsed", "deprecation", "SameParameterValue"})
public class SqlCodeStyleSettings extends CustomCodeStyleSettings implements SqlCodeStyleConst {

  public int myVersion = SqlCodeStyleSettingsDefault.CURRENT_VERSION;


  /// INITIALIZATION \\\

  public SqlCodeStyleSettings(CodeStyleSettings container) {
    super("SqlCodeStyleSettings", container);
  }

  @Override
  public SqlCodeStyleSettings clone() {
    SqlCodeStyleSettings clone = (SqlCodeStyleSettings)super.clone();
    clone.myVersion = this.myVersion;
    return clone;
  }


  /// GLOBAL OPTIONS \\\

  public boolean DISABLE_FORMATTING = false;


  /// CASING \\\

  @AliasCase
  public int ALIAS_CASE = MODERN.ALIAS_CASE;

  @IdentifierCase
  public int KEYWORD_CASE = MODERN.KEYWORD_CASE;

  @IdentifierCaseExt
  public int TYPE_CASE = MODERN.TYPE_CASE;

  @IdentifierCase
  public int IDENTIFIER_CASE = MODERN.IDENTIFIER_CASE;
  
  @IdentifierCase
  public int QUOTED_IDENTIFIER_CASE = MODERN.QUOTED_IDENTIFIER_CASE;

  @NotNull
  public static Case getCaseMode(@IdentifierCase int codeStyleSetting) {
    return codeStyleSetting == TO_UPPER ? Case.UPPER :
           codeStyleSetting == TO_LOWER ? Case.LOWER :
           Case.MIXED;
  }

  @NotNull
  public Case getCaseModeExt(@IdentifierCaseExt int codeStyleSetting) {
    if (codeStyleSetting == AS_KEYWORDS) return getCaseModeExt(KEYWORD_CASE);
    return getCaseMode(codeStyleSetting);
  }


  /// IDENTIFIER QUOTATION \\\

  @MagicConstant(intValues = {QUOTE, UNQUOTE, DO_NOT_CHANGE})
  public int QUOTE_IDENTIFIER = MODERN.QUOTE_IDENTIFIER;


  /// QUERY & DML COMMON  \\

  @MagicConstant(intValues = {AS_IS, QUERY_SECTION_1ST_WORD_ALIGN_LEFT, QUERY_SECTION_1ST_WORD_ALIGN_LEFT_INDENT, QUERY_SECTION_1ST_WORD_ALIGN_RIGHT})
  public int QUERY_SECTION_1ST_WORD_ALIGN = MODERN.QUERY_SECTION_1ST_WORD_ALIGN;

  @MagicConstant(intValues = {AS_IS, EL_SAME, EL_INDENT})
  public int QUERY_EL_LINE = MODERN.QUERY_EL_LINE;

  @MagicConstant(intValues = {AS_IS, QUERY_IN_ONE_STRING_NO, QUERY_IN_ONE_STRING_INNER_ONLY, QUERY_IN_ONE_STRING_YES})
  public int QUERY_IN_ONE_STRING = MODERN.QUERY_IN_ONE_STRING;


  /// SUBQUERY \\\

  public boolean SUBQUERY_L_PAR_NL_OUTSIDE = MODERN.SUBQUERY_L_PAR_NL_OUTSIDE;
  public boolean SUBQUERY_L_PAR_NL_INSIDE = MODERN.SUBQUERY_L_PAR_NL_INSIDE;
  public boolean SUBQUERY_R_PAR_NL_INSIDE = MODERN.SUBQUERY_R_PAR_NL_INSIDE;

  @MagicConstant(intValues = {SUBQUERY_R_PAR_ALIGN_TO_L_PAR, SUBQUERY_R_PAR_ALIGN_TO_L_PAR_2, SUBQUERY_R_PAR_ALIGN_TO_QUERY})
  public int SUBQUERY_R_PAR_ALIGN = MODERN.SUBQUERY_R_PAR_ALIGN;

  public boolean SUBQUERY_INDENT_INSIDE = MODERN.SUBQUERY_INDENT_INSIDE;
  public boolean SUBQUERY_PAR_SPACE_INSIDE = MODERN.SUBQUERY_PAR_SPACE_INSIDE;


  /// SECTION INSERT \\\

  @MagicConstant(intValues = {AS_IS, ADD, REMOVE})
  public int INSERT_INTO_NL = MODERN.INSERT_INTO_NL;


  /// SECTION VALUES \\\

  public boolean INSERT_COLLAPSE_MULTI_ROW_VALUES = MODERN.INSERT_COLLAPSE_MULTI_ROW_VALUES;


  /// SECTION SET \\\

  @MagicConstant(intValues = {AS_IS, EL_CHOP, EL_CHOP_LONG, EL_WRAP})
  public int SET_EL_WRAP = MODERN.SET_EL_WRAP;

  @MagicConstant(intValues = {AS_IS, EL_COMMA_1ST, EL_COMMA_LAST})
  public int SET_EL_COMMA = MODERN.SET_EL_COMMA;

  public boolean SET_ALIGN_EQUAL_SIGN = MODERN.SET_ALIGN_EQUAL_SIGN;



  /// SECTION WITH \\\

  @MagicConstant(intValues = {AS_IS, EL_CHOP, EL_CHOP_LONG, EL_WRAP})
  public int WITH_EL_WRAP = MODERN.WITH_EL_WRAP;

  @MagicConstant(intValues = {AS_IS, EL_COMMA_1ST, EL_COMMA_LAST})
  public int WITH_EL_COMMA = MODERN.WITH_EL_COMMA;

  public boolean WITH_ALIGN_AS = MODERN.WITH_ALIGN_AS;


  /// SECTION SELECT \\\

  @MagicConstant(intValues = {AS_IS, EL_CHOP, EL_CHOP_LONG, EL_WRAP})
  public int SELECT_EL_WRAP = MODERN.SELECT_EL_WRAP;    // change to AS_IS

  @MagicConstant(intValues = {AS_IS, EL_COMMA_1ST, EL_COMMA_LAST})
  public int SELECT_EL_COMMA = MODERN.SELECT_EL_COMMA;  // change to AS_IS

  public boolean SELECT_NEW_LINE_AFTER_ALL_DISTINCT = MODERN.SELECT_NEW_LINE_AFTER_ALL_DISTINCT;

  public int SELECT_KEEP_N_ITEMS_IN_LINE = MODERN.SELECT_KEEP_N_ITEMS_IN_LINE; // change to 0

  @MagicConstant(intValues = {AS_IS, ADD, REMOVE})
  public int SELECT_USE_AS_WORD = MODERN.SELECT_USE_AS_WORD;

  public boolean SELECT_ALIGN_AS = MODERN.SELECT_ALIGN_AS;


  /// SECTION FROM \\\

  @MagicConstant(intValues = {AS_IS, EL_CHOP, EL_CHOP_LONG})
  public int FROM_EL_WRAP = MODERN.FROM_EL_WRAP;   // change to EL_CHOP

  @MagicConstant(intValues = {AS_IS, EL_COMMA_1ST, EL_COMMA_LAST})
  public int FROM_EL_COMMA = MODERN.FROM_EL_COMMA; // change to AS_IS

  public boolean FROM_WRAP_JOIN_1 = MODERN.FROM_WRAP_JOIN_1;
  public boolean FROM_WRAP_JOIN_2 = MODERN.FROM_WRAP_JOIN_2;
  public boolean FROM_WRAP_ON = MODERN.FROM_WRAP_ON;

  public boolean FROM_ALIGN_JOIN_TABLES = MODERN.FROM_ALIGN_JOIN_TABLES;
  public boolean FROM_ALIGN_ALIASES = MODERN.FROM_ALIGN_ALIASES;

  public boolean FROM_INDENT_JOIN = MODERN.FROM_INDENT_JOIN;


  /// SECTION WHERE \\\

  @MagicConstant(intValues = {AS_IS, EL_CHOP, EL_CHOP_LONG, EL_WRAP})
  public int WHERE_EL_WRAP = MODERN.WHERE_EL_WRAP;  // change to AS_IS

  @MagicConstant(intValues = {AS_IS, EL_COMMA_1ST, EL_COMMA_LAST})
  public int WHERE_EL_BOUND = MODERN.WHERE_EL_BOUND;  // change to AS_IS


  /// SECTIONS GROUP/ORDER \\\

  @MagicConstant(intValues = {AS_IS, EL_CHOP, EL_CHOP_LONG, EL_WRAP})
  public int ORDER_EL_WRAP = MODERN.ORDER_EL_WRAP; // change to AS_IS

  @MagicConstant(intValues = {AS_IS, EL_COMMA_1ST, EL_COMMA_LAST})
  public int ORDER_EL_COMMA = MODERN.ORDER_EL_COMMA; // change to AS_IS

  public boolean ORDER_ALIGN_ASC_DESC = MODERN.ORDER_ALIGN_ASC_DESC;


  /// EXPRESSIONS \\\

  public boolean CORTEGE_SPACE_BEFORE_L_PAREN = MODERN.CORTEGE_SPACE_BEFORE_L_PAREN; // change to true
  public boolean CORTEGE_COMMA_1ST = MODERN.CORTEGE_COMMA_1ST;

  @MagicConstant(intValues = {AS_IS, CORTEGE_CLOSING_UNDER_OPENING, CORTEGE_CLOSING_UNDER_ITEM, CORTEGE_CLOSING_AT_THE_END})
  public int CORTEGE_CLOSING = MODERN.CORTEGE_CLOSING;

  @MagicConstant(intValues = {AS_IS, ADD, REMOVE})
  public int EXPR_SPACE_AROUND_OPERATOR = MODERN.EXPR_SPACE_AROUND_OPERATOR;

  public boolean EXPR_BINARY_OP_ALIGN = MODERN.EXPR_BINARY_OP_ALIGN;

  public boolean EXPR_CASE_WHEN_WRAP = MODERN.EXPR_CASE_WHEN_WRAP;
  public boolean EXPR_CASE_WHEN_INDENT = MODERN.EXPR_CASE_WHEN_INDENT;
  public boolean EXPR_CASE_THEN_WRAP = MODERN.EXPR_CASE_THEN_WRAP; // change to false
  public boolean EXPR_CASE_THEN_ALIGN = MODERN.EXPR_CASE_THEN_ALIGN;
  public boolean EXPR_CASE_ELSE_ALIGN_THEN = MODERN.EXPR_CASE_ELSE_ALIGN_THEN;

  @MagicConstant(intValues = {AS_IS, EXPR_CASE_END_ALIGN_CASE, EXPR_CASE_END_ALIGN_WHEN, EXPR_CASE_END_TO_THE_END})
  public int EXPR_CASE_END = MODERN.EXPR_CASE_END;

  public boolean EXPR_CASE_KEEP_NL_AFTER_THEN = MODERN.EXPR_CASE_KEEP_NL_AFTER_THEN;
  public boolean EXPR_CASE_COLLAPSE = MODERN.EXPR_CASE_COLLAPSE;


  /// OTHER \\\

  public String INDEX_NAME_TEMPLATE       = MODERN.INDEX_NAME_TEMPLATE;
  public String PRIMARY_KEY_NAME_TEMPLATE = MODERN.PRIMARY_KEY_NAME_TEMPLATE;
  public String FOREIGN_KEY_NAME_TEMPLATE = MODERN.FOREIGN_KEY_NAME_TEMPLATE;


  /// DEPRECATED \\\

  @Deprecated public boolean SPACES_AROUND_OPERATORS                  = LEGACY.SPACES_AROUND_OPERATORS;

  @Deprecated public boolean ALIGN_AS_IN_SELECT_STATEMENT             = LEGACY.ALIGN_AS_IN_SELECT_STATEMENT;
  @Deprecated public boolean ALIGN_TYPE_IN_CREATE_STATEMENT           = LEGACY.ALIGN_TYPE_IN_CREATE_STATEMENT;
  @Deprecated public boolean ALIGN_TYPE_IN_BLOCK_STATEMENT            = LEGACY.ALIGN_TYPE_IN_BLOCK_STATEMENT;
  @Deprecated public boolean ALIGN_TYPE_IN_ARGUMENT_DEFINITION        = LEGACY.ALIGN_TYPE_IN_ARGUMENT_DEFINITION;
  @Deprecated public boolean ALIGN_INSIDE_BINARY_EXPRESSION           = LEGACY.ALIGN_INSIDE_BINARY_EXPRESSION;
  @Deprecated public boolean ALIGN_INSIDE_QUERY_EXPRESSION            = LEGACY.ALIGN_INSIDE_QUERY_EXPRESSION;
  @Deprecated public boolean ALIGN_EQ_INSIDE_SET_CLAUSE               = LEGACY.ALIGN_EQ_INSIDE_SET_CLAUSE;

  @Deprecated public boolean NEW_LINE_BEFORE_FROM                     = LEGACY.NEW_LINE_BEFORE_FROM;
  @Deprecated public boolean NEW_LINE_BEFORE_JOIN                     = LEGACY.NEW_LINE_BEFORE_JOIN;
  @Deprecated public boolean NEW_LINE_BEFORE_JOIN_CONDITION           = LEGACY.NEW_LINE_BEFORE_JOIN_CONDITION;
  @Deprecated public boolean NEW_LINE_BEFORE_WHERE                    = LEGACY.NEW_LINE_BEFORE_WHERE;
  @Deprecated public boolean NEW_LINE_BEFORE_GROUP_BY                 = LEGACY.NEW_LINE_BEFORE_GROUP_BY;
  @Deprecated public boolean NEW_LINE_BEFORE_ORDER_BY                 = LEGACY.NEW_LINE_BEFORE_ORDER_BY;
  @Deprecated public boolean NEW_LINE_BEFORE_HAVING                   = LEGACY.NEW_LINE_BEFORE_HAVING;
  @Deprecated public boolean NEW_LINE_BEFORE_THEN                     = LEGACY.NEW_LINE_BEFORE_THEN;
  @Deprecated public boolean NEW_LINE_BEFORE_ELSE                     = LEGACY.NEW_LINE_BEFORE_ELSE;
  @Deprecated public boolean NEW_LINE_BEFORE_OTHER_CLAUSES            = LEGACY.NEW_LINE_BEFORE_OTHER_CLAUSES;
  @Deprecated public boolean NEW_LINE_BEFORE_COMMA                    = LEGACY.NEW_LINE_BEFORE_COMMA;
  @Deprecated public boolean NEW_LINE_BEFORE_QUERY_INSIDE_PARENTHESIS = LEGACY.NEW_LINE_BEFORE_QUERY_INSIDE_PARENTHESIS;
  @Deprecated public boolean NEW_LINE_BEFORE_QUERY_INSIDE_DML         = LEGACY.NEW_LINE_BEFORE_QUERY_INSIDE_DML;
  @Deprecated public boolean NEW_LINE_AROUND_SEMICOLON                = LEGACY.NEW_LINE_AROUND_SEMICOLON;

  @Deprecated public boolean INDENT_JOIN                              = LEGACY.INDENT_JOIN;
  @Deprecated public boolean INDENT_JOIN_CONDITION                    = LEGACY.INDENT_JOIN_CONDITION;
  @Deprecated public boolean INDENT_SELECT_INTO_CLAUSE                = LEGACY.INDENT_SELECT_INTO_CLAUSE;

  @Deprecated public int WRAP_INSIDE_CREATE_TABLE                     = LEGACY.WRAP_INSIDE_CREATE_TABLE;
  @Deprecated public int WRAP_INSIDE_SELECT                           = LEGACY.WRAP_INSIDE_SELECT;
  @Deprecated public int WRAP_INSIDE_JOIN_EXPRESSION                  = LEGACY.WRAP_INSIDE_JOIN_EXPRESSION;
  @Deprecated public int WRAP_INSIDE_GROUP_BY                         = LEGACY.WRAP_INSIDE_GROUP_BY;
  @Deprecated public int WRAP_INSIDE_WHERE                            = LEGACY.WRAP_INSIDE_WHERE;
  @Deprecated public int WRAP_INSIDE_ORDER_BY                         = LEGACY.WRAP_INSIDE_ORDER_BY;
  @Deprecated public int WRAP_INSIDE_SET                              = LEGACY.WRAP_INSIDE_SET;
  @Deprecated public int WRAP_INSIDE_ARGUMENT_DEFINITION              = LEGACY.WRAP_INSIDE_ARGUMENT_DEFINITION;
  @Deprecated public int WRAP_INSIDE_CALL_EXPRESSION                  = LEGACY.WRAP_INSIDE_CALL_EXPRESSION;
  @Deprecated public int WRAP_INSIDE_VALUES_EXPRESSION                = LEGACY.WRAP_INSIDE_VALUES_EXPRESSION;
  @Deprecated public int WRAP_VALUES_EXPRESSION                       = LEGACY.WRAP_VALUES_EXPRESSION;
  @Deprecated public int WRAP_PARENTHESIZED_EXPRESSION_INSIDE_VALUES  = LEGACY.WRAP_PARENTHESIZED_EXPRESSION_INSIDE_VALUES;

  @Deprecated public boolean NEW_LINE_AFTER_SELECT                    = LEGACY.NEW_LINE_AFTER_SELECT;
  @Deprecated public boolean NEW_LINE_AFTER_SELECT_ITEM               = LEGACY.NEW_LINE_AFTER_SELECT_ITEM;
  @Deprecated public int NEW_LINE_AFTER_SELECT_2                      = LEGACY.NEW_LINE_AFTER_SELECT_2;


  /// MIGRATION \\\

  private static final Logger LOG = Logger.getInstance(SqlCodeStyleSettings.class);


  @Override
  public void readExternal(Element parentElement) throws InvalidDataException {
    Element sectionElement = parentElement.getChild(getTagName());
    if (sectionElement == null) return;

    myVersion = readIntAttribute(sectionElement, "version");
    if (myVersion == 0) assignDefaults(LEGACY);
    
    super.readExternal(parentElement);
  }

  @Override
  public void writeExternal(Element parentElement, @NotNull CustomCodeStyleSettings parentSettings) throws WriteExternalException {
    super.writeExternal(parentElement, parentSettings);

    Element sectionElement = parentElement.getChild(getTagName());
    if (sectionElement != null) {
      sectionElement.setAttribute("version", Integer.toString(myVersion));
    }
  }

  private static int readIntAttribute(@Nullable Element element, @NotNull String attributeName) {
    String value = readStringAttribute(element, attributeName);
    if (value == null) return 0;
    value = value.trim();
    try {
      return Integer.parseInt(value);
    }
    catch (NumberFormatException nfe) {
      LOG.warn("Reading SQL code style settings: Wrong integer attribute value: "+'"'+value+'"');
      return 0;
    }
  }

  @Nullable
  private static String readStringAttribute(@Nullable Element element, @NotNull String attributeName) {
    if (element == null) return null;
    return element.getAttributeValue(attributeName);
  }


  @Override
  public void beforeLoading() {
    //myVersion = 0;
  }

  @Override
  public void afterLoaded() {
    switch (myVersion) {
      case 0: migrateFromVersion0();
    }
  }



  @SuppressWarnings("deprecation")
  private void migrateFromVersion0() {
    LOG.debug("Migrating SQL code style settings from version 0");

    CommonCodeStyleSettings c = getCommonSettings();

    int x = countValue(WRAP_ALWAYS,
                       WRAP_INSIDE_SET, WRAP_INSIDE_SELECT, WRAP_INSIDE_WHERE, WRAP_INSIDE_GROUP_BY, WRAP_INSIDE_ORDER_BY);
    if (x <= 2) QUERY_EL_LINE = EL_SAME;
    else if (x >= 4) QUERY_EL_LINE = EL_INDENT;
    else QUERY_EL_LINE = AS_IS;

    SUBQUERY_L_PAR_NL_OUTSIDE = c.SPACE_BEFORE_METHOD_PARENTHESES;
    SUBQUERY_L_PAR_NL_INSIDE = NEW_LINE_BEFORE_QUERY_INSIDE_PARENTHESIS;
    SUBQUERY_PAR_SPACE_INSIDE = c.SPACE_WITHIN_PARENTHESES;

    SET_ALIGN_EQUAL_SIGN = ALIGN_EQ_INSIDE_SET_CLAUSE;

    SELECT_EL_WRAP = convertWrap(WRAP_INSIDE_SELECT);
    SELECT_KEEP_N_ITEMS_IN_LINE = WRAP_INSIDE_SELECT == WRAP_ALWAYS ? 0 : 7;
    SELECT_ALIGN_AS = ALIGN_AS_IN_SELECT_STATEMENT;

    //noinspection MagicConstant
    FROM_EL_WRAP = convertWrap(WRAP_INSIDE_JOIN_EXPRESSION);
    //noinspection MagicConstant
    if (FROM_EL_WRAP == EL_WRAP) FROM_EL_WRAP = EL_CHOP_LONG;

    FROM_WRAP_JOIN_1 = NEW_LINE_BEFORE_JOIN;
    FROM_WRAP_JOIN_2 = NEW_LINE_BEFORE_JOIN;
    FROM_INDENT_JOIN = INDENT_JOIN;

    WHERE_EL_WRAP = convertWrap(WRAP_INSIDE_WHERE);

    ORDER_EL_WRAP = convertWrap(WRAP_INSIDE_ORDER_BY);

    SELECT_EL_COMMA = FROM_EL_COMMA = ORDER_EL_COMMA =
      NEW_LINE_BEFORE_COMMA ? EL_COMMA_1ST : EL_COMMA_LAST;

    CORTEGE_SPACE_BEFORE_L_PAREN = c.SPACE_BEFORE_METHOD_PARENTHESES;
    CORTEGE_COMMA_1ST = NEW_LINE_BEFORE_COMMA;

    EXPR_SPACE_AROUND_OPERATOR = SPACES_AROUND_OPERATORS ? ADD : REMOVE;
    EXPR_BINARY_OP_ALIGN = ALIGN_INSIDE_BINARY_EXPRESSION;
    EXPR_CASE_THEN_WRAP = NEW_LINE_BEFORE_THEN;
  }


  @NotNull
  private CommonCodeStyleSettings getCommonSettings() {
    CodeStyleSettings container = getContainer();
    assert container != null : "The container of SQL custom settings must not be null";
    return container.getCommonSettings(SqlLanguage.INSTANCE);
  }

  @SuppressWarnings("ForLoopReplaceableByForEach")
  private static int countValue(final int valueToCount, final int... values) {
    int m = 0;
    for (int i = 0, n = values.length; i < n; i++) if (values[i] == valueToCount) m++;
    return m;
  }


  @Contract(pure = true)
  @MagicConstant(intValues = {AS_IS, EL_CHOP, EL_CHOP_LONG, EL_WRAP})
  private static int convertWrap(int oldWrap) {
    switch (oldWrap) {
      case WRAP_ALWAYS: return EL_CHOP;
      case WRAP_ON_EVERY_ITEM: return EL_CHOP_LONG;
      case WRAP_AS_NEEDED: return EL_WRAP;
      default: return AS_IS;
    }
  }


  public void manuallyChanged() {
    if (myVersion < SqlCodeStyleSettingsDefault.CURRENT_VERSION) {
      LOG.info(format("SQL code style settings version updated from %d to %d (because they were manually changed)",
                      myVersion, SqlCodeStyleSettingsDefault.CURRENT_VERSION));
      myVersion = SqlCodeStyleSettingsDefault.CURRENT_VERSION;
    }
  }


  private void assignDefaults(@NotNull SqlCodeStyleSettingsDefault def) {
    assignModernDefaults(def);
    assignLegacyDefaults(def);
  }

  
  private void assignModernDefaults(@NotNull SqlCodeStyleSettingsDefault def) {
    // @formatter:off
    ALIAS_CASE                                    = def.ALIAS_CASE;
    KEYWORD_CASE                                  = def.KEYWORD_CASE;
    TYPE_CASE                                     = def.TYPE_CASE;
    IDENTIFIER_CASE                               = def.IDENTIFIER_CASE;
    QUOTED_IDENTIFIER_CASE                        = def.QUOTED_IDENTIFIER_CASE;
    QUOTE_IDENTIFIER                              = def.QUOTE_IDENTIFIER;
    QUERY_SECTION_1ST_WORD_ALIGN                  = def.QUERY_SECTION_1ST_WORD_ALIGN;
    QUERY_EL_LINE                                 = def.QUERY_EL_LINE;
    QUERY_IN_ONE_STRING                           = def.QUERY_IN_ONE_STRING;
    SUBQUERY_L_PAR_NL_OUTSIDE                     = def.SUBQUERY_L_PAR_NL_OUTSIDE;
    SUBQUERY_L_PAR_NL_INSIDE                      = def.SUBQUERY_L_PAR_NL_INSIDE;
    SUBQUERY_R_PAR_NL_INSIDE                      = def.SUBQUERY_R_PAR_NL_INSIDE;
    SUBQUERY_R_PAR_ALIGN                          = def.SUBQUERY_R_PAR_ALIGN;
    SUBQUERY_INDENT_INSIDE                        = def.SUBQUERY_INDENT_INSIDE;
    SUBQUERY_PAR_SPACE_INSIDE                     = def.SUBQUERY_PAR_SPACE_INSIDE;
    INSERT_INTO_NL                                = def.INSERT_INTO_NL;
    INSERT_COLLAPSE_MULTI_ROW_VALUES              = def.INSERT_COLLAPSE_MULTI_ROW_VALUES;
    SET_EL_WRAP                                   = def.SET_EL_WRAP;
    SET_EL_COMMA                                  = def.SET_EL_COMMA;
    SET_ALIGN_EQUAL_SIGN                          = def.SET_ALIGN_EQUAL_SIGN;
    WITH_EL_WRAP                                  = def.WITH_EL_WRAP;
    WITH_EL_COMMA                                 = def.WITH_EL_COMMA;
    WITH_ALIGN_AS                                 = def.WITH_ALIGN_AS;
    SELECT_EL_WRAP                                = def.SELECT_EL_WRAP;
    SELECT_EL_COMMA                               = def.SELECT_EL_COMMA;
    SELECT_NEW_LINE_AFTER_ALL_DISTINCT            = def.SELECT_NEW_LINE_AFTER_ALL_DISTINCT;
    SELECT_KEEP_N_ITEMS_IN_LINE                   = def.SELECT_KEEP_N_ITEMS_IN_LINE;
    SELECT_USE_AS_WORD                            = def.SELECT_USE_AS_WORD;
    SELECT_ALIGN_AS                               = def.SELECT_ALIGN_AS;
    FROM_EL_WRAP                                  = def.FROM_EL_WRAP;
    FROM_EL_COMMA                                 = def.FROM_EL_COMMA;
    FROM_WRAP_JOIN_1                              = def.FROM_WRAP_JOIN_1;
    FROM_WRAP_JOIN_2                              = def.FROM_WRAP_JOIN_2;
    FROM_WRAP_ON                                  = def.FROM_WRAP_ON;
    FROM_ALIGN_JOIN_TABLES                        = def.FROM_ALIGN_JOIN_TABLES;
    FROM_ALIGN_ALIASES                            = def.FROM_ALIGN_ALIASES;
    FROM_INDENT_JOIN                              = def.FROM_INDENT_JOIN;
    WHERE_EL_WRAP                                 = def.WHERE_EL_WRAP;
    WHERE_EL_BOUND                                = def.WHERE_EL_BOUND;
    ORDER_EL_WRAP                                 = def.ORDER_EL_WRAP;
    ORDER_EL_COMMA                                = def.ORDER_EL_COMMA;
    ORDER_ALIGN_ASC_DESC                          = def.ORDER_ALIGN_ASC_DESC;
    CORTEGE_SPACE_BEFORE_L_PAREN                  = def.CORTEGE_SPACE_BEFORE_L_PAREN;
    CORTEGE_COMMA_1ST                             = def.CORTEGE_COMMA_1ST;
    CORTEGE_CLOSING                               = def.CORTEGE_CLOSING;
    EXPR_SPACE_AROUND_OPERATOR                    = def.EXPR_SPACE_AROUND_OPERATOR;
    EXPR_BINARY_OP_ALIGN                          = def.EXPR_BINARY_OP_ALIGN;
    EXPR_CASE_WHEN_WRAP                           = def.EXPR_CASE_WHEN_WRAP;
    EXPR_CASE_WHEN_INDENT                         = def.EXPR_CASE_WHEN_INDENT;
    EXPR_CASE_THEN_WRAP                           = def.EXPR_CASE_THEN_WRAP;
    EXPR_CASE_THEN_ALIGN                          = def.EXPR_CASE_THEN_ALIGN;
    EXPR_CASE_ELSE_ALIGN_THEN                     = def.EXPR_CASE_ELSE_ALIGN_THEN;
    EXPR_CASE_END                                 = def.EXPR_CASE_END;
    EXPR_CASE_KEEP_NL_AFTER_THEN                  = def.EXPR_CASE_KEEP_NL_AFTER_THEN;
    EXPR_CASE_COLLAPSE                            = def.EXPR_CASE_COLLAPSE;
    INDEX_NAME_TEMPLATE                           = def.INDEX_NAME_TEMPLATE;
    PRIMARY_KEY_NAME_TEMPLATE                     = def.PRIMARY_KEY_NAME_TEMPLATE;
    FOREIGN_KEY_NAME_TEMPLATE                     = def.FOREIGN_KEY_NAME_TEMPLATE;
    // @formatter:on
  }


  private void assignLegacyDefaults(@NotNull SqlCodeStyleSettingsDefault def) {
    // @formatter:off
    SPACES_AROUND_OPERATORS                       = def.SPACES_AROUND_OPERATORS;
    ALIGN_AS_IN_SELECT_STATEMENT                  = def.ALIGN_AS_IN_SELECT_STATEMENT;
    ALIGN_TYPE_IN_CREATE_STATEMENT                = def.ALIGN_TYPE_IN_CREATE_STATEMENT;
    ALIGN_TYPE_IN_BLOCK_STATEMENT                 = def.ALIGN_TYPE_IN_BLOCK_STATEMENT;
    ALIGN_TYPE_IN_ARGUMENT_DEFINITION             = def.ALIGN_TYPE_IN_ARGUMENT_DEFINITION;
    ALIGN_INSIDE_BINARY_EXPRESSION                = def.ALIGN_INSIDE_BINARY_EXPRESSION;
    ALIGN_INSIDE_QUERY_EXPRESSION                 = def.ALIGN_INSIDE_QUERY_EXPRESSION;
    ALIGN_EQ_INSIDE_SET_CLAUSE                    = def.ALIGN_EQ_INSIDE_SET_CLAUSE;
    NEW_LINE_BEFORE_FROM                          = def.NEW_LINE_BEFORE_FROM;
    NEW_LINE_BEFORE_JOIN                          = def.NEW_LINE_BEFORE_JOIN;
    NEW_LINE_BEFORE_JOIN_CONDITION                = def.NEW_LINE_BEFORE_JOIN_CONDITION;
    NEW_LINE_BEFORE_WHERE                         = def.NEW_LINE_BEFORE_WHERE;
    NEW_LINE_BEFORE_GROUP_BY                      = def.NEW_LINE_BEFORE_GROUP_BY;
    NEW_LINE_BEFORE_ORDER_BY                      = def.NEW_LINE_BEFORE_ORDER_BY;
    NEW_LINE_BEFORE_HAVING                        = def.NEW_LINE_BEFORE_HAVING;
    NEW_LINE_BEFORE_THEN                          = def.NEW_LINE_BEFORE_THEN;
    NEW_LINE_BEFORE_ELSE                          = def.NEW_LINE_BEFORE_ELSE;
    NEW_LINE_BEFORE_OTHER_CLAUSES                 = def.NEW_LINE_BEFORE_OTHER_CLAUSES;
    NEW_LINE_BEFORE_COMMA                         = def.NEW_LINE_BEFORE_COMMA;
    NEW_LINE_BEFORE_QUERY_INSIDE_PARENTHESIS      = def.NEW_LINE_BEFORE_QUERY_INSIDE_PARENTHESIS;
    NEW_LINE_BEFORE_QUERY_INSIDE_DML              = def.NEW_LINE_BEFORE_QUERY_INSIDE_DML;
    NEW_LINE_AROUND_SEMICOLON                     = def.NEW_LINE_AROUND_SEMICOLON;
    INDENT_JOIN                                   = def.INDENT_JOIN;
    INDENT_JOIN_CONDITION                         = def.INDENT_JOIN_CONDITION;
    INDENT_SELECT_INTO_CLAUSE                     = def.INDENT_SELECT_INTO_CLAUSE;
    WRAP_INSIDE_CREATE_TABLE                      = def.WRAP_INSIDE_CREATE_TABLE;
    WRAP_INSIDE_SELECT                            = def.WRAP_INSIDE_SELECT;
    WRAP_INSIDE_JOIN_EXPRESSION                   = def.WRAP_INSIDE_JOIN_EXPRESSION;
    WRAP_INSIDE_GROUP_BY                          = def.WRAP_INSIDE_GROUP_BY;
    WRAP_INSIDE_WHERE                             = def.WRAP_INSIDE_WHERE;
    WRAP_INSIDE_ORDER_BY                          = def.WRAP_INSIDE_ORDER_BY;
    WRAP_INSIDE_SET                               = def.WRAP_INSIDE_SET;
    WRAP_INSIDE_ARGUMENT_DEFINITION               = def.WRAP_INSIDE_ARGUMENT_DEFINITION;
    WRAP_INSIDE_CALL_EXPRESSION                   = def.WRAP_INSIDE_CALL_EXPRESSION;
    WRAP_INSIDE_VALUES_EXPRESSION                 = def.WRAP_INSIDE_VALUES_EXPRESSION;
    WRAP_VALUES_EXPRESSION                        = def.WRAP_VALUES_EXPRESSION;
    WRAP_PARENTHESIZED_EXPRESSION_INSIDE_VALUES   = def.WRAP_PARENTHESIZED_EXPRESSION_INSIDE_VALUES;
    NEW_LINE_AFTER_SELECT                         = def.NEW_LINE_AFTER_SELECT;
    NEW_LINE_AFTER_SELECT_ITEM                    = def.NEW_LINE_AFTER_SELECT_ITEM;
    NEW_LINE_AFTER_SELECT_2                       = def.NEW_LINE_AFTER_SELECT_2;
    // @formatter:on
  }


}