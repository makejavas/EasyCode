package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlCreateAssertionStatement extends SqlCreateStatement {
}
