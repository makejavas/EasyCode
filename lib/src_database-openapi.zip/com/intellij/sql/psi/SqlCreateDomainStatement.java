package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlCreateDomainStatement extends SqlCreateStatement, SqlTypedDefinition {
}
